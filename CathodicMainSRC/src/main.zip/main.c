/*************************************************************
//	Main program
//	------------------------------------------------------
//	Project Name : Cathodic Debonding Tester
//	Model Name  : ACT-100M
//	Start Date  : 2016.06.17
//	Chip Number : STM32F103VGT
//	C-Compiler	: EWARM
//	Written by 	: jhKim
//  COPYRIGHT (c) 2010 AddSol All rights reserved.
**************************************************************/

#include <string.h>
#include "includes.h"
#include "main.h"
#include "user.h"
#include "IOdefine.h"
#include "Uart.h"
#include "timer.h"
#include "mmi.h" 
#include "io_macros.h"
#include "dsp.h"
#include "rpm_data.h"
#include "stm32f10x_flash.h"


u8	ASCII[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

#define sbit(x,y) (x |= (0x1<<y))  	
#define cbit(x,y) (x &= ~(0x1<<y)) 	
#define tbit(x,y) (x & (0x1<<y))  

static __IO ErrorStatus HSEStartUpStatus = SUCCESS;
u16 	gu16ALive_Cpu_Dly;

/////////////////////// Model HB ///////////////////////////////////
union {
 	u8 CmdData[8];
 	struct {
 	unsigned char  Cancel_Initialization :1; /* Cancel Initialization of SPW Position */
 				//0x0: No Action,
				//0x1: Cancel Initialization
	unsigned char WindowEnable :1; /* Operation Condition */
 				//0x0: No Action,
				//0x1: Enable
 	unsigned char WindowCMD_FL :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Express Down,
				//0x6: Express Up
				//0x7: Short Drop
 	unsigned char WindowCMD_FR :3; /* SPW control Command */
	
 	unsigned char WindowLock :2; /* Window Lock Switch Status */
 				//0x0: OFF,
				//0x1: RR Lock,
				//0x2: AST_RR Lock
	unsigned char WindowCMD_RL :3; /* SPW control Command */
	unsigned char WindowCMD_RR :3; /* SPW control Command */
	
	unsigned char WindowCentralCMD :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Central Open
				//0x2: Central Close
				//0x3: Short Drop
				//0x4: Long Drop
	unsigned char IGNSw :3; /* Ignition Key Status */
 				//0x0: Key Off
				//0x1: Key In
				//0x2: ACC
				//0x3: IGN
				//0x4: START
	unsigned char DrvDrSwW :1; /* Door Open Status */
 				//0x0: Closed,
				//0x1: Opened
	unsigned char AstDrSw :1; /* Door Open Status */
	unsigned char RLDrSw :1; /* Door Open Status */
	unsigned char RRDrSw :1; /* Door Open Status */
	unsigned char CrashOutput :1; /* Crash Information of ACU */
 				//0x0: No Action,
				//0x1: Crash
	unsigned char NoName0 :5;
	 	
	unsigned char IntTailOn :1; /* Interior Illumination */
 				//0x0: Tail Lamp Off,
				//0x1: Tail Lamp On
	unsigned char RheostatLevel :5; /* Rheostat Level */
 				//0x0: Reserved
				//0x1~0x14: Step1~20
				//0x15: Step 21(Detent)
	unsigned char DetentOut :1; /* Rheostat detent status */
 				//0x0: Off
				//0x1: On
	unsigned char NoName1 :1;
	
	unsigned char OutTempC :8; /* Outside Temperature */
 				//0x0~0xFE: 0~254
				//0xFF: Error
	unsigned char VehicleSpeed :8; /* Vehicle Speed Information */
 				//0x0~0xFE: 0~254
				//0xFF: Error
	unsigned char NoName2 :8;
 	} Bits;
} CMDDATA_HB;

union {
 	u8 StateData[6];
 	struct {
 	unsigned char WdwPosition :3; /* Window Glass Position */
 				//0x0: Full Close,
				//0x1: 75% Close
				//0x2: 50% Close
				//0x3: 25% Close
				//0x4: Full Open
				//0x5: Invalid
 	unsigned char WdwReverse :1; /* Window Reverse Action of Anti-pitch */
 				//0x0: No Action,
				//0x1: Reverse Action
	unsigned char NoName3 :1;	/* No name */
 	unsigned char LocalSwStatus :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Express Down,
				//0x6: Express Up
				//0x7: Invalid
 	unsigned char WdwErr :4; /* SPW Error State */
 				//0x0: No error
				//0x1: Thermal Protection Active
				//0x2: Anti Pinch de-calibrated
				//0x3: Parameter checksum error
				//0x4: RAM error
				//0x5: ROM/Flash checksum error
				//0x6: Relay/FET Error
				//0x7: Undifined ECU Error
				//0x8: Switch Error
				//0x9: Invalid
 	unsigned char WindowSW_Master :3; /*SPW FR Switch Status on Master Switch */
 				//0x0: No Action
				//0x1: Manual Down
				//0x2: Manual Up
				//0x5: Express Down
				//0x6: Express Up
				//0x7: Short Drop
 	} Bits;
} STATEDATA_HB;

///////////////////////// Mode JF /////////////////////
//typedef
union {
 	u8 CmdData[4];
 	struct {
	 unsigned char Cancel_Initialization :1; /* Cancel Initialization of SPW Position */
 				//0x0: No Action,
				//0x1: Cancel Initialization
 	unsigned char WindowEnable :1; /* Operation Condition */
 				//0x0: No Action,
				//0x1: Enable
 	unsigned char WindowCMD_FL :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Express Down,
				//0x6: Express Up
				//0x7: Short Drop
 	unsigned char WindowCMD_FR :3; /* SPW control Command */
	
 	unsigned char WindowLock :2; /* Window Lock Switch Status */
 				//0x0: OFF,
				//0x1: RR Lock,
				//0x2: AST_RR Lock
	unsigned char WindowCMD_RL :3; /* SPW control Command */
	unsigned char WindowCMD_RR :3; /* SPW control Command */
	
	unsigned char WindowCentralCMD :2; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Central Open
				//0x2: Central Close
				//0x3: Short Drop
				//0x4: Long Drop
	unsigned char DrvDrSwW :1; /* Door Open Status */
 				//0x0: Closed,
				//0x1: Opened
	unsigned char AstDrSw :1; /* Door Open Status */
	unsigned char RLDrSw :1; /* Door Open Status */
	unsigned char RRDrSw :1; /* Door Open Status */
	unsigned char NoName0 :2;
	unsigned char VehicleSpeed :8; /* Vehicle Speed Information */
 				//0x0~0xFE: 0~254
				//0xFF: Error
 	} Bits;
} CMDDATA_JF;

union {
 	u8 StateData[2];
 	struct {
 	unsigned char WdwPosition :2; /* Window Glass Position */
 				//0x0: Full Close,
				//0x1: 75% Close
				//0x2: 50% Close
				//0x3: 25% Close
				//0x4: Full Open
				//0x5: Invalid
 	unsigned char WdwReverse :1; /* Window Reverse Action of Anti-pitch */
 				//0x0: No Action,
				//0x1: Reverse Action

 	unsigned char LocalSwStatus :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Express Down,
				//0x6: Express Up
				//0x7: Invalid
 	unsigned char WdwErr :2; /* SPW Error State */
 				//0x0: No error
				//0x1: Thermal Protection Active
				//0x2: Anti Pinch de-calibrated
				//0x3: Parameter checksum error
				//0x4: RAM error
				//0x5: ROM/Flash checksum error
				//0x6: Relay/FET Error
				//0x7: Undifined ECU Error
				//0x8: Switch Error
				//0x9: Invalid
 	unsigned char WindowSW_Master :3; /*SPW FR Switch Status on Master Switch */
 				//0x0: No Action
				//0x1: Manual Down
				//0x2: Manual Up
				//0x5: Express Down
				//0x6: Express Up
				//0x7: Short Drop
	unsigned char NoName3 :5;	/* No name */
 	} Bits;
} STATEDATA2_JF;

union {
 	u8 StateData;
 	struct {
 	unsigned char WdwPosition :2; /* Window Glass Position */
 				//0x0: Full Close,
				//0x1: 75% Close
				//0x2: 50% Close
				//0x3: 25% Close
				//0x4: Full Open
				//0x5: Invalid
 	unsigned char WdwReverse :1; /* Window Reverse Action of Anti-pitch */
 				//0x0: No Action,
				//0x1: Reverse Action

 	unsigned char LocalSwStatus :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Express Down,
				//0x6: Express Up
				//0x7: Invalid
 	unsigned char WdwErr :2; /* SPW Error State */
 				//0x0: No error
				//0x1: Thermal Protection Active
				//0x2: Anti Pinch de-calibrated
				//0x3: Parameter checksum error
				//0x4: RAM error
				//0x5: ROM/Flash checksum error
				//0x6: Relay/FET Error
				//0x7: Undifined ECU Error
				//0x8: Switch Error
				//0x9: Invalid
 	} Bits;
} STATEDATA1_JF;
//////////////////////////////////// GSB ///////////////////////////////////
union {
 	u8 CmdData[3];
 	struct {
 	unsigned char Cancel_Initialization :1; /* Cancel Initialization of SPW Position */
 				//0x0: No Action,
				//0x1: Cancel Initialization
 	unsigned char WindowEnable :1; /* Operation Condition */
 				//0x0: No Action,
				//0x1: Enable
 	unsigned char WindowLock :2; /* Window Lock Switch Status */
 				//0x0: OFF,
				//0x1: RR Lock,
				//0x2: AST_RR Lock

 	unsigned char RemoteWindowCMD :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Central Manual Down,
				//0x2: Central Manual Up,
				//0x3: Central Auto Dwon(reserved)
				//0x4: Central Auto Up
				//0x7: Stop
	unsigned char NoName1 :1;
	unsigned char IGNSw :3; /* Ignition Key Status */
 				//0x0: Key Off
				//0x1: Key In
				//0x2: ACC
				//0x3: IGN
				//0x4: START
	unsigned char DrvDrSwW :1; /* Door Open Status */
 				//0x0: Closed,
				//0x1: Opened
	unsigned char AstDrSw :1; /* Door Open Status */
	unsigned char RLDrSw :1; /* Door Open Status */
	unsigned char RRDrSw :1; /* Door Open Status */
	unsigned char BodyType :1; /*Body Type */
				//0x0: LHD,
				//0x1: RHD	
	unsigned char VehicleSpeed :8; /* Vehicle Speed Information */
 				//0x0~0xFE: 0~254
				//0xFF: Error
 	} Bits;
} CMDDATA_GSB;


union {
 	u8 StateData[2];
 	struct {
 	unsigned char WdwPosition :1; /* Window Glass Position */
 				//0x0: Full Close,
				//0x1: Full Open
	unsigned char LocalSwStatus :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Express Down,
				//0x6: Express Up
				//0x7: Invalid
 	unsigned char APinch_decalibrated :1; /* SPW Erro State */
 				//0x0: Calibrated
				//0x1: De-Calibrated

 
 	unsigned char MovingStatus :3; /* SPW Motor Moving Status */
				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x3: RLY Stuck/FET Error
				//0x5: Auto Down,
				//0x6: Auto Up
				//0x7: Reverse
	unsigned char PullUpVoltage :8; /* PullUp Voltage State */
				//0x0~0xFE: 0~254
				//0xFF: Error

 	} Bits;
} STATEDATA2_GSB;

//////////////////////////////////// TM ///////////////////////////////////
union {
 	u8 CmdData[4];
 	struct {
	unsigned char Cancel_Initialization :1; /* Cancel Initialization of SPW Position */
 				//0x0: No Action,
				//0x1: Cancel Initialization
	unsigned char WindowLock :1; /* Window Lock Switch Status */
 				//0x0: OFF,
				//0x1: RR Lock,
	unsigned char WindowEnable :1; /* Operation Condition */
 				//0x0: No Action,
				//0x1: Enable
	unsigned char WindowSTS_FL_IBU :3; 
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Auto Dwon
				//0x6: Auto Up
				//0x7: Short Drop
	unsigned char NoName1 :2; 


	unsigned char WindowSTS_FR_IBU :3; 
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Auto Dwon
				//0x6: Auto Up
				//0x7: Short Drop
	 unsigned char WindowSTS_RL_IBU :3; 
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Auto Dwon
				//0x6: Auto Up
				//0x7: Short Drop
	unsigned char NoName2 :2;

	unsigned char WindowSTS_RR_IBU :3; 
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x5: Auto Dwon
				//0x6: Auto Up
				//0x7: Short Drop
	unsigned char WindowCentralCMD :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Central Manual Down
				//0x2: Central Manual Up
				//0x3: Central Auto Down (reserved)
				//0x4: Central Auto Up
				//0x7: Stop
	unsigned char NoName3 :2;

	unsigned char VehicleSpeed :8; /* Vehicle Speed Information */
 				//0x0~0xFE: 0~254
				//0xFF: Error
 	} Bits;
} CMDDATA_TM;


union {
 	u8 StateData[3];
 	struct {
	unsigned char WdwPosition :1; /* Window Glass Position */
 				//0x0: Full Close,
				//0x1: Full Open
	unsigned char LocalSwStatus :3; /* SPW control Command */
 				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x2: Stuck
				//0x5: Auto Down,
				//0x6: Auto Up
				//0x7: Invalid
	 unsigned char APinch_decalibrated :1; /* SPW Erro State */
 				//0x0: Calibrated
				//0x1: De-Calibrated
	unsigned char WdwErr_Thermal :1; /* SPW Erro State */
 				//0x0: No error
				//0x1: error
 	unsigned char ERR_RESP_SPW :1; /* SPW Erro State */
 				//0x0: No error
				//0x1: error
	unsigned char NoName1 :1; 

	unsigned char WindowSTS_SPW :3; /* SPW Motor Moving Status */
				//0x0: No Action,
				//0x1: Manual Down,
				//0x2: Manual Up,
				//0x3: RLY Stuck/FET Error
				//0x4: Motor Stop Error
				//0x5: Auto Down,
				//0x6: Auto Up
				//0x7: Reverse
	unsigned char NoName2 :5; 

	unsigned char PullUpVoltage :8; /* PullUp Voltage State */
				//0x0~0xFE: 0~254
				//0xFF: Error

 	} Bits;
} STATEDATA2_TM;
//////////////////////////////////// SQ ///////////////////////////////////
union {
 	u8 CmdData[8];
 	struct {
	unsigned char WindowSunroofCloseCMD		:1;// start: 0;
	unsigned char WindowLock					:1;// start: 1;
	unsigned char WindowEnable				:1;// start: 2;
	unsigned char WindowSWSTS_FL_IBU			:3;// start: 3;
	unsigned char NoName1 					:2;// start: 6; 
	unsigned char WindowSWSTS_FR_IBU			:3;// start: 8;
	unsigned char WindowSWSTS_RL_IBU			:3;// start:11;
	unsigned char NoName2 					:2;// start: 14;
	unsigned char WindowSWSTS_RR_IBU			:3;// start: 16;
	unsigned char WindowCentralCMD			:3;// start: 19;
	unsigned char NoName3 					:2;// start: 22;
	unsigned char WindowLINCMD_FL_IBU		:3;// start: 24;
	unsigned char WindowLINCMD_FR_IBU		:3;// start: 27;
	unsigned char NoName4 					:2;// start: 30;
	unsigned char WindowLINCMD_RL_IBU		:3;// start: 32;
	unsigned char WindowLINCMD_RR_IBU		:3;// start: 35;
	unsigned char NoName5 					:2;// start: 38;
	unsigned char Operation_Glass				:3;// start: 40;
	unsigned char Operation_R_Blind				:2;// start: 43;
	unsigned char NoName6 					:3;// start: 45;
	unsigned char VehicleSpeed					:8;// start: 48;
	unsigned char DATC_OutTempDis				:8;// start: 56;
 	} Bits;
} CMDDATA_SQ;


union {
 	u8 StateData[4];
 	struct {
	unsigned char LIN_WdwPosition		:1;// start: 0 ;
	unsigned char LocalSw1Status 		:3;// start: 1 ;
	unsigned char LIN_WdwErr_AntiPinch	:1;// start: 4 ;
	unsigned char LIN_WdwErr_Thermal	:1;// start: 5 ;
	unsigned char ERR_RESP_SPW		:1;// start: 6 ;
	unsigned char NoName1 			:1;// start: 7; 
	unsigned char LIN_WindowSTS_SPW	:3;// start: 8 ;
	unsigned char LocalSw2Status		:3;// start: 11 ;
	unsigned char LIN_WindowOpenState	:2;// start: 14 ;
	unsigned char LocalSw1VoltageLevel	:8;// start: 16 ;
	unsigned char LocalSw2VoltagleLevel	:8;// start: 24 ;    
 	} Bits;
} STATEDATA_SQ;

//////////////////////////////////// S111  ///////////////////////////////////
union {
 	u8 CmdData[8];
 	struct {

	unsigned char BCM_IGNStatus :2;			 //, 0 ;
	unsigned char BCM_ComfortCommandReq:3;	//, 2 ;
	unsigned char BCM_WRAuthorization:1;		//, 5 ;
	unsigned char BCM_ChildlockReq:1;			//, 6 ;
	unsigned char NoName1 :1; 

	unsigned char BCM_WL_FL_ControlReq:3;	//, 8 ;
	unsigned char BCM_WL_FR_ControlReq:3;	//, 11 ;
	unsigned char BCM_DriverDoorLockStatus:2;//, 14 ;

	unsigned char BCM_WL_RL_ControlReq:3;	//, 16 ;
	unsigned char BCM_WL_RR_ControlReq:3;	//, 19 ;
	unsigned char BCM_KeyAlarmStatus:2;		//, 22 ;

	unsigned char BCM_VehicleSpeed:8;			//, 24 ;

	unsigned char BCM_EnvironmentalTemp:8;	//, 32 ;

	unsigned char BCM_TCU_GearShiftPositon:4;	//, 40 ;
	unsigned char BCM_PTS_RemoteCommand:1;//, 44 ;
	unsigned char BCM_PEPS_EASY_OPEN:1;		//, 45 ;
	unsigned char BCM_LearnCommand:1;		//, 46 ;
	unsigned char BCM_UNLearnCommand:1;	//, 47 ;

	unsigned char BCM_ClearDTCcommand:1;	//, 48 ;
	unsigned char BCM_PTSpeCommand:1;		//, 49 ;
	unsigned char BCM_WL_Sunroof_ControlReq:3;//, 50 ;
	unsigned char BCM_PTS_TrunkSW:1;		//, 53 ;
	unsigned char BCM_PTS_TrunkPEButton:1;	//, 54 ;
	unsigned char NoName2 :1; 

	unsigned char NoName3 :8; 
 	} Bits;
} CMDDATA_S111;

union {
 	u8 StateData[4];
 	struct {
	unsigned char DDCU_WL_Initialized			:1;//, 0 ;
	unsigned char DDCU_WL_Status				:2;//, 1 ;
    	unsigned char DDCU_WL_APActive			:1;//, 3 ;
    	unsigned char DDCU_WL_ECUError			:1;//, 4 ;
    	unsigned char DDCU_WL_SwitchError		:1;//, 5 ;
    	unsigned char DDCU_WL_HallError			:1;//, 6 ;
    	unsigned char DDCU_Response_Error		:1;//, 7 ;
    	unsigned char DDCU_POS_VIT				:8;//, 8 ;
    	unsigned char DDCU_Childlock_SW_Input	:1;//, 16 ;
    	unsigned char DDCU_WR_FR_Switch_Req	:3;//, 17 ;
    	unsigned char DDCU_WR_RL_Switch_Req 	:3;//20 ;
    	unsigned char NoName1					:1;//23
    	unsigned char DDCU_WR_RR_Switch_Req, 	:3;//24 ;
    	unsigned char NoNmae2					:5;//27
 	} Bits;
} STATEDATA4_S111;

union {
 	u8 StateData[2];
 	struct {
 	unsigned char PDCU_WL_Initialized			:1;//, 0 ;
    	unsigned char PDCU_WL_Status				:2;//, 1 ;
    	unsigned char PDCU_WL_APActive			:1;//, 3 ;
    	unsigned char PDCU_WL_ECUError			:1;//, 4 ;
    	unsigned char PDCU_WL_SwitchError		:1;//, 5 ;
    	unsigned char PDCU_WL_HallError			:1;//, 6 ;
    	unsigned char PDCU_Response_Error		:1;//, 7 ;
    	unsigned char PDCU_POS_VIT				:8;//, 8 ;
 	} Bits;
} STATEDATA2_S111;

u8	gu8_ModbusData[256];

LIN_message  MSG_SEND;
LIN_frame 	LIN_RX_FRAME;

u8			gu8_Buf_Test_Index;
u8			gu8_Buf_Test[40];
LIN_state 	g_State_Test[40];

u8 			gu8_LinByteIn;
u8			gu8_LinDataLength; // data length
u8			gu8_LinRxDataCounter;// data input counter

u8			gu8_Usart2_Tx_Buf[60];
u8			gu8_Usart2_Tx_Buf_Index;
u8			gu8_Usart2_Tx_Data_Length;


u8			gu8_fRxEnable;
u16			gu16_Rx_Over_Tm;		/* Rx0 Over Timer */
u8 			gu8_iFront;
u8			gu8_iRear;
u8			gu8_RxBuf[60];
u8			gu8_TxBuf[60];
u8			gu8_fLinTxEnable;
u8 			gu8_ID[6] = {0x15, 0x16,0x17,0x18,0x19,0x20};
u8			gu8_S111_ID[5]={1, 16,17,18,19};				// S111
//u8		gu8_Else_ID[5] = {0x15, 0x16,0x17,0x18,0x19};//HB, JF, GSB, TM,SQ,
u8 			gu8_ID_Index = 0;

u8			gu8_fReceive;

u8 			gu8_Temp;

u8 			gu8_TxBuf_Length;
u8 			gu8_fTxDataEnable;

u8			gu8_FL_LedDly;
u8			gu8_FR_LedDly;
u8			gu8_RL_LedDly;
u8			gu8_RR_LedDly;

u8			gu8_Cmd_Length;
u8 			gu8_FL_Length;
u8 			gu8_FR_Length;
u8 			gu8_RL_Length;
u8 			gu8_RR_Length;

u8 			gu8_Cmd_Delay;
u8 			gu8_FL_Delay;
u8 			gu8_FR_Delay;
u8 			gu8_RL_Delay;
u8 			gu8_RR_Delay;

u16			gu16_LinTxDly;
u8			gu8_Cmd_LedDly;
u8			gu8_FL_LedDly;
u8			gu8_FR_LedDly;
u8			gu8_RL_LedDly;
u8			gu8_RR_LedDly;

u8			gu8_FL_Connected;
u8			gu8_FR_Connected;
u8			gu8_RL_Connected;
u8			gu8_RR_Connected;

u8			gu8_Rx_Test_Buf_Index;

LIN_state 	gu8_LinTxStatue;

u8			gu8_LinSlaveType;

u8			gu8_Selected_Signal;
u8			gu8_Signal_Select_Dly_Enable;
u8			gu8_Signal_Select_Dly;
//u8			gu8_Chsel_Value;
u8			gu8_JF_SW_Value;
u8			gu8_Enable_Power_Cylinder_Value;
/*******************************************************************************
* Function Name  : Main Service
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void main(void)
{

	System_Init();	

	Delay_ms(100);
	//Variable_Initial();
	gu8_fLinTxEnable = 1;

	while (1)
 	{
 		ALive_Cpu();
 		Led_Process_Task();
 		Com_PcToMaster( );
		Com_MasterToPc();
 		Model_Select( gu8_ModbusData[MD_MODEL_ADDR]);
 		Lin_Model_Run();
// 		Model_Total();
 		Board_Control();
 	/*
	       ALive_Cpu();
	       Com_Pc_To_Main_Rx();
	       Com_Main_To_Pc_Tx();
	       if(gu8_Always)	Alawys_Run();
	       else  			Unit_Run();
	       Temperature_Task();
	       Trigger_Task();
	       Test_Task();
          
          */
 	}
}
/***********************************************************************
	Function Name  : 
 	Parameter      : void
 	Returned Value : void
 	Comments       : 
***********************************************************************/
void Model_Read(void)
{
	u8 Value=0;

	
	if(Value > 0)
	{
		gu8_ModbusData[39] = Value - 1;
	}

}
void ModbusDataToCommand_HB(void)
{
	u8 Addr = MB_CMD_ADDR;
	CMDDATA_HB.Bits.Cancel_Initialization 	= gu8_ModbusData[Addr++]; /* Cancel Initialization of SPW Position */
	CMDDATA_HB.Bits.WindowEnable 		= gu8_ModbusData[Addr++]; /* Operation Condition */
 	CMDDATA_HB.Bits.WindowCMD_FL 		= gu8_ModbusData[Addr++]; /* SPW control Command */
 	CMDDATA_HB.Bits.WindowCMD_FR 		= gu8_ModbusData[Addr++]; /* SPW control Command */	
 	CMDDATA_HB.Bits.WindowLock 			= gu8_ModbusData[Addr++]; /* Window Lock Switch Status */
	CMDDATA_HB.Bits.WindowCMD_RL 		= gu8_ModbusData[Addr++]; /* SPW control Command */
	CMDDATA_HB.Bits.WindowCMD_RR 		= gu8_ModbusData[Addr++]; /* SPW control Command */
	CMDDATA_HB.Bits.WindowCentralCMD 	= gu8_ModbusData[Addr++]; /* SPW control Command */
	CMDDATA_HB.Bits.IGNSw 				= gu8_ModbusData[Addr++]; /* Ignition Key Status */
	CMDDATA_HB.Bits.DrvDrSwW			= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_HB.Bits.AstDrSw 				= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_HB.Bits.RLDrSw				= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_HB.Bits.RRDrSw 				= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_HB.Bits.CrashOutput 			= gu8_ModbusData[Addr++]; /* Crash Information of ACU */
	CMDDATA_HB.Bits.IntTailOn 			= gu8_ModbusData[Addr++]; /* Interior Illumination */
	CMDDATA_HB.Bits.RheostatLevel 		= gu8_ModbusData[Addr++]; /* Rheostat Level */
	CMDDATA_HB.Bits.DetentOut 			= gu8_ModbusData[Addr++]; /* Rheostat detent status */
	CMDDATA_HB.Bits.OutTempC 			= gu8_ModbusData[Addr++]; /* Outside Temperature */
	CMDDATA_HB.Bits.VehicleSpeed 			= gu8_ModbusData[Addr++]; /* Vehicle Speed Information */

	CMDDATA_HB.Bits.WindowEnable = 1;/* Operation Condition */
}
void ModbusDataToCommand_JF(void)
{
	u8 Addr = MB_CMD_ADDR;
	CMDDATA_JF.Bits.Cancel_Initialization 	= gu8_ModbusData[Addr++]; /* Cancel Initialization of SPW Position */
 	CMDDATA_JF.Bits.WindowEnable 			= gu8_ModbusData[Addr++]; /* Operation Condition */
 	CMDDATA_JF.Bits.WindowCMD_FL 		= gu8_ModbusData[Addr++]; /* SPW control Command */
 	CMDDATA_JF.Bits.WindowCMD_FR 		= gu8_ModbusData[Addr++]; /* SPW control Command */
 	CMDDATA_JF.Bits.WindowLock			= gu8_ModbusData[Addr++]; /* Window Lock Switch Status */
	CMDDATA_JF.Bits.WindowCMD_RL 		= gu8_ModbusData[Addr++]; /* SPW control Command */
	CMDDATA_JF.Bits.WindowCMD_RR 		= gu8_ModbusData[Addr++]; /* SPW control Command */
	CMDDATA_JF.Bits.WindowCentralCMD 	= gu8_ModbusData[Addr++]; /* SPW control Command */
	CMDDATA_JF.Bits.DrvDrSwW 			= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_JF.Bits.AstDrSw 				= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_JF.Bits.RLDrSw 				= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_JF.Bits.RRDrSw 				= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_JF.Bits.VehicleSpeed 			= gu8_ModbusData[Addr++]; /* Vehicle Speed Information */

	
	CMDDATA_JF.Bits.WindowEnable = 1;/* Operation Condition */
	
}
void ModbusDataToCommand_GSB(void)
{
	u8 Addr = MB_CMD_ADDR;
	CMDDATA_GSB.Bits.Cancel_Initialization 	= gu8_ModbusData[Addr++]; /* Cancel Initialization of SPW Position */
 	CMDDATA_GSB.Bits.WindowEnable  		= gu8_ModbusData[Addr++]; /* Operation Condition */
 	CMDDATA_GSB.Bits.WindowLock 			= gu8_ModbusData[Addr++]; /* Window Lock Switch Status */
 	CMDDATA_GSB.Bits.RemoteWindowCMD  	= gu8_ModbusData[Addr++]; /* SPW control Command */
	CMDDATA_GSB.Bits.IGNSw 				= gu8_ModbusData[Addr++]; /* Ignition Key Status */
	CMDDATA_GSB.Bits.DrvDrSwW 			= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_GSB.Bits.AstDrSw 			= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_GSB.Bits.RLDrSw 			= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_GSB.Bits.RRDrSw 			= gu8_ModbusData[Addr++]; /* Door Open Status */
	CMDDATA_GSB.Bits.BodyType 			= gu8_ModbusData[Addr++]; /*Body Type */
	CMDDATA_GSB.Bits.VehicleSpeed 		= gu8_ModbusData[Addr++]; /* Vehicle Speed Informa */

	CMDDATA_GSB.Bits.WindowEnable = 1;/* Operation Condition */
}
void ModbusDataToCommand_TM(void)
{
	u8 Addr = MB_CMD_ADDR;
	CMDDATA_TM.Bits.Cancel_Initialization 	= gu8_ModbusData[Addr++]; /* Cancel Initialization of SPW Position */
	CMDDATA_TM.Bits.WindowLock 			= gu8_ModbusData[Addr++]; /* Window Lock Switch Status */
	CMDDATA_TM.Bits.WindowEnable 		= gu8_ModbusData[Addr++]; /* Operation Condition */
	CMDDATA_TM.Bits.WindowSTS_FL_IBU 	= gu8_ModbusData[Addr++]; 
	CMDDATA_TM.Bits.WindowSTS_FR_IBU 	= gu8_ModbusData[Addr++]; 
	 CMDDATA_TM.Bits.WindowSTS_RL_IBU 	= gu8_ModbusData[Addr++]; 
	CMDDATA_TM.Bits.WindowSTS_RR_IBU 	= gu8_ModbusData[Addr++]; 
	CMDDATA_TM.Bits.WindowCentralCMD 	= gu8_ModbusData[Addr++]; /* SPW control Command */
	CMDDATA_TM.Bits.VehicleSpeed 			= gu8_ModbusData[Addr++]; /* Vehicle Speed Information */

	CMDDATA_TM.Bits.WindowEnable = 1;/* Operation Condition */
}
void ModbusDataToCommand_SQ(void)
{
	u8 Addr = MB_CMD_ADDR;
	CMDDATA_SQ.Bits.WindowSunroofCloseCMD	= gu8_ModbusData[Addr++];// start: 0;
	CMDDATA_SQ.Bits.WindowLock				= gu8_ModbusData[Addr++];// start: 1;
	CMDDATA_SQ.Bits.WindowEnable				= gu8_ModbusData[Addr++];// start: 2;
	CMDDATA_SQ.Bits.WindowSWSTS_FL_IBU		= gu8_ModbusData[Addr++];// start: 3;
	CMDDATA_SQ.Bits.WindowSWSTS_FR_IBU		= gu8_ModbusData[Addr++];// start: 8;
	CMDDATA_SQ.Bits.WindowSWSTS_RL_IBU		= gu8_ModbusData[Addr++];// start:11;
	CMDDATA_SQ.Bits.WindowSWSTS_RR_IBU		= gu8_ModbusData[Addr++];// start: 16;
	CMDDATA_SQ.Bits.WindowCentralCMD		= gu8_ModbusData[Addr++];// start: 19;
	CMDDATA_SQ.Bits.WindowLINCMD_FL_IBU		= gu8_ModbusData[Addr++];// start: 24;
	CMDDATA_SQ.Bits.WindowLINCMD_FR_IBU	= gu8_ModbusData[Addr++];// start: 27;
	CMDDATA_SQ.Bits.WindowLINCMD_RL_IBU	= gu8_ModbusData[Addr++];// start: 32;
	CMDDATA_SQ.Bits.WindowLINCMD_RR_IBU	= gu8_ModbusData[Addr++];// start: 35;
	CMDDATA_SQ.Bits.Operation_Glass			= gu8_ModbusData[Addr++];// start: 40;
	CMDDATA_SQ.Bits.Operation_R_Blind			= gu8_ModbusData[Addr++];// start: 43;
	CMDDATA_SQ.Bits.VehicleSpeed				= gu8_ModbusData[Addr++];// start: 48;
	CMDDATA_SQ.Bits.DATC_OutTempDis			= gu8_ModbusData[Addr++];// start: 56;

	CMDDATA_SQ.Bits.WindowEnable = 1;/* Operation Condition */
}
void ModbusDataToCommand_S111(void)
{
	u8 Addr = MB_CMD_ADDR;
	CMDDATA_S111.Bits.BCM_IGNStatus 				= gu8_ModbusData[Addr++];	//, 0 ;
	CMDDATA_S111.Bits.BCM_ComfortCommandReq	= gu8_ModbusData[Addr++];	//, 2 ;
	CMDDATA_S111.Bits.BCM_WRAuthorization		= gu8_ModbusData[Addr++];	//, 5 ;
	CMDDATA_S111.Bits.BCM_ChildlockReq			= gu8_ModbusData[Addr++];	//, 6 ;
	CMDDATA_S111.Bits.BCM_WL_FL_ControlReq		= gu8_ModbusData[Addr++];	//, 8 ;
	CMDDATA_S111.Bits.BCM_WL_FR_ControlReq		= gu8_ModbusData[Addr++];	//, 11 ;
	CMDDATA_S111.Bits.BCM_DriverDoorLockStatus	= gu8_ModbusData[Addr++];	//, 14 ;
	CMDDATA_S111.Bits.BCM_WL_RL_ControlReq		= gu8_ModbusData[Addr++];	//, 16 ;
	CMDDATA_S111.Bits.BCM_WL_RR_ControlReq		= gu8_ModbusData[Addr++];	//, 19 ;
	CMDDATA_S111.Bits.BCM_KeyAlarmStatus		= gu8_ModbusData[Addr++];	//, 22 ;
	CMDDATA_S111.Bits.BCM_VehicleSpeed			= gu8_ModbusData[Addr++];	//, 24 ;
	CMDDATA_S111.Bits.BCM_EnvironmentalTemp		= gu8_ModbusData[Addr++];	//, 32 ;
	CMDDATA_S111.Bits.BCM_TCU_GearShiftPositon	= gu8_ModbusData[Addr++];	//, 40 ;
	CMDDATA_S111.Bits.BCM_PTS_RemoteCommand	= gu8_ModbusData[Addr++];	//, 44 ;
	CMDDATA_S111.Bits.BCM_PEPS_EASY_OPEN		= gu8_ModbusData[Addr++];	//, 45 ;
	CMDDATA_S111.Bits.BCM_LearnCommand		= gu8_ModbusData[Addr++];	//, 46 ;
	CMDDATA_S111.Bits.BCM_UNLearnCommand		= gu8_ModbusData[Addr++];	//, 47 ;
	CMDDATA_S111.Bits.BCM_ClearDTCcommand		= gu8_ModbusData[Addr++];	//, 48 ;
	CMDDATA_S111.Bits.BCM_PTSpeCommand		= gu8_ModbusData[Addr++];	//, 49 ;
	CMDDATA_S111.Bits.BCM_WL_Sunroof_ControlReq	= gu8_ModbusData[Addr++];	//, 50 ;
	CMDDATA_S111.Bits.BCM_PTS_TrunkSW			= gu8_ModbusData[Addr++];	//, 53 ;
	CMDDATA_S111.Bits.BCM_PTS_TrunkPEButton		= gu8_ModbusData[Addr++];	//, 54 ;

	CMDDATA_S111.Bits.BCM_WRAuthorization = 1;/* Operation Condition */
}
void Move_Command(void)
{
	u8 i;
	
	switch(gu8_ModbusData[MD_MODEL_ADDR])
	{
		case MOTOR_HB:
			ModbusDataToCommand_HB();
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_HB.CmdData[i];
			}
			break;
		case MOTOR_JF:
			ModbusDataToCommand_JF();
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_JF.CmdData[i];
			}
			break;
		case MOTOR_GSB:
			ModbusDataToCommand_GSB();
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_GSB.CmdData[i];
			}
			break;
		case MOTOR_TM:
			ModbusDataToCommand_TM();
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_TM.CmdData[i];
			}
			break;
		case MOTOR_SQ:
			ModbusDataToCommand_SQ();
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_SQ.CmdData[i];
			}
			break;
		case MOTOR_S111:
			ModbusDataToCommand_S111();
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_S111.CmdData[i];
			}
			break;
	}
}
void Command_Move(void)
{
	u8 i;
	
	switch(gu8_ModbusData[MD_MODEL_ADDR])
	{
		case MOTOR_HB:
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_HB.CmdData[i];
			}
			break;
		case MOTOR_JF:
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_JF.CmdData[i];
			}
			break;
		case MOTOR_GSB:
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_GSB.CmdData[i];
			}
			break;
		case MOTOR_TM:
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_TM.CmdData[i];
			}
			break;
		case MOTOR_SQ:
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_SQ.CmdData[i];
			}
			break;
		case MOTOR_S111:
			for( i =0; i < gu8_Cmd_Length; i++)
			{
				MSG_SEND.gu8_DataField[i] = CMDDATA_S111.CmdData[i];
			}
			break;
	}
}
///////////////////////////////////////////////////////////////////////////////
void Move_FL_Data(void)
{
	switch(gu8_ModbusData[MD_MODEL_ADDR])
	{
		case MOTOR_HB:
			STATEDATA_HB.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA_HB.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[19] = STATEDATA_HB.Bits.WdwPosition;
	       	gu8_ModbusData[20] = STATEDATA_HB.Bits.WdwReverse;
	       	gu8_ModbusData[21] = STATEDATA_HB.Bits.LocalSwStatus;
	       	gu8_ModbusData[22] = STATEDATA_HB.Bits.WdwErr;
	       	gu8_ModbusData[23] = STATEDATA_HB.Bits.WindowSW_Master;
			break;
		case MOTOR_JF:
			STATEDATA2_JF.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_JF.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[19] = STATEDATA2_JF.Bits.WdwPosition;
	       	gu8_ModbusData[20] = STATEDATA2_JF.Bits.WdwReverse;
	       	gu8_ModbusData[21] = STATEDATA2_JF.Bits.LocalSwStatus;
	       	gu8_ModbusData[22] = STATEDATA2_JF.Bits.WdwErr;
	       	gu8_ModbusData[23] = STATEDATA2_JF.Bits.WindowSW_Master;
			break;
		case MOTOR_GSB:
			STATEDATA2_GSB.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_GSB.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[19] = STATEDATA2_GSB.Bits.WdwPosition;
	       	gu8_ModbusData[20] = STATEDATA2_GSB.Bits.APinch_decalibrated;
	       	gu8_ModbusData[21] = STATEDATA2_GSB.Bits.LocalSwStatus;
	       	gu8_ModbusData[22] = STATEDATA2_GSB.Bits.MovingStatus;
	       	gu8_ModbusData[23] = STATEDATA2_GSB.Bits.PullUpVoltage;
			break;
		case MOTOR_TM:
			STATEDATA2_TM.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_TM.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA2_TM.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	gu8_ModbusData[19] = STATEDATA2_TM.Bits.WdwPosition;
	       	gu8_ModbusData[20] = STATEDATA2_TM.Bits.APinch_decalibrated;
	       	gu8_ModbusData[21] = STATEDATA2_TM.Bits.LocalSwStatus;
	       	//ModbusData[22] = STATEDATA2_TM.Bits.MovingStatus;
	       	gu8_ModbusData[23] = STATEDATA2_TM.Bits.PullUpVoltage;
			break;
		case MOTOR_SQ:
			STATEDATA_SQ.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA_SQ.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA_SQ.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	STATEDATA_SQ.StateData[3] = LIN_RX_FRAME.gu8_Data[3];
	       	gu8_ModbusData[19] = STATEDATA_SQ.Bits.LIN_WdwPosition;
	       	gu8_ModbusData[20] = STATEDATA_SQ.Bits.LIN_WdwErr_AntiPinch;
	       	gu8_ModbusData[21] = STATEDATA_SQ.Bits.LIN_WindowSTS_SPW;
	       	gu8_ModbusData[22] = STATEDATA_SQ.Bits.LIN_WdwErr_Thermal;
	       	gu8_ModbusData[23] = STATEDATA_SQ.Bits.ERR_RESP_SPW;
			break;
		case MOTOR_S111:
			STATEDATA4_S111.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA4_S111.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA4_S111.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	STATEDATA4_S111.StateData[3] = LIN_RX_FRAME.gu8_Data[3];
	       	break;
			
	}
}
///////////////////////////////////////////////////////////////////////////////
void Move_FR_Data(void)
{
	switch(gu8_ModbusData[MD_MODEL_ADDR])
	{
		case MOTOR_HB:
			STATEDATA_HB.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA_HB.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[24] = STATEDATA_HB.Bits.WdwPosition;
	       	gu8_ModbusData[25] = STATEDATA_HB.Bits.WdwReverse;
	       	gu8_ModbusData[26] = STATEDATA_HB.Bits.LocalSwStatus;
	       	gu8_ModbusData[27] = STATEDATA_HB.Bits.WdwErr;
	       	gu8_ModbusData[28] = STATEDATA_HB.Bits.WindowSW_Master;
			break;
		case MOTOR_JF:
			STATEDATA2_JF.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_JF.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[24] = STATEDATA2_JF.Bits.WdwPosition;
	       	gu8_ModbusData[25] = STATEDATA2_JF.Bits.WdwReverse;
	       	gu8_ModbusData[26] = STATEDATA2_JF.Bits.LocalSwStatus;
	       	gu8_ModbusData[27] = STATEDATA2_JF.Bits.WdwErr;
	       	gu8_ModbusData[28] = STATEDATA2_JF.Bits.WindowSW_Master;
			break;
		case MOTOR_GSB:
			STATEDATA2_GSB.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_GSB.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[24] = STATEDATA2_GSB.Bits.WdwPosition;
	       	gu8_ModbusData[25] = STATEDATA2_GSB.Bits.APinch_decalibrated;
	       	gu8_ModbusData[26] = STATEDATA2_GSB.Bits.LocalSwStatus;
	       	gu8_ModbusData[27] = STATEDATA2_GSB.Bits.MovingStatus;
	       	gu8_ModbusData[28] = STATEDATA2_GSB.Bits.PullUpVoltage;
			break;
		case MOTOR_TM:
			STATEDATA2_TM.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_TM.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA2_TM.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	gu8_ModbusData[24] = STATEDATA2_TM.Bits.WdwPosition;
	       	gu8_ModbusData[25] = STATEDATA2_TM.Bits.APinch_decalibrated;
	       	gu8_ModbusData[26] = STATEDATA2_TM.Bits.LocalSwStatus;
	       	//ModbusData[27] = STATEDATA2_TM.Bits.MovingStatus;
	       	gu8_ModbusData[28] = STATEDATA2_TM.Bits.PullUpVoltage;
			break;
		case MOTOR_SQ:
			STATEDATA_SQ.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA_SQ.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA_SQ.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	STATEDATA_SQ.StateData[3] = LIN_RX_FRAME.gu8_Data[3];
	       	gu8_ModbusData[24] = STATEDATA_SQ.Bits.LIN_WdwPosition;
	       	gu8_ModbusData[25] = STATEDATA_SQ.Bits.LIN_WdwErr_AntiPinch;
	       	gu8_ModbusData[26] = STATEDATA_SQ.Bits.LIN_WindowSTS_SPW;
       		gu8_ModbusData[27] = STATEDATA_SQ.Bits.LIN_WdwErr_Thermal;
	       	gu8_ModbusData[28] = STATEDATA_SQ.Bits.ERR_RESP_SPW;
	       	break;
	       case MOTOR_S111:
	       	STATEDATA2_S111.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_S111.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	break;
	}
}

///////////////////////////////////////////////////////////////////////////////
void Move_RL_Data(void)
{
	switch(gu8_ModbusData[MD_MODEL_ADDR])
	{
		case MOTOR_HB:
			STATEDATA_HB.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA_HB.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[29] = STATEDATA_HB.Bits.WdwPosition;
	       	gu8_ModbusData[30] = STATEDATA_HB.Bits.WdwReverse;
	       	gu8_ModbusData[31] = STATEDATA_HB.Bits.LocalSwStatus;
	       	gu8_ModbusData[32] = STATEDATA_HB.Bits.WdwErr;
			break;
		case MOTOR_JF:
			STATEDATA1_JF.StateData = LIN_RX_FRAME.gu8_Data[0];
			//STATEDATA.StateData[1] = LIN_RX_FRAME.data[1];
	       	gu8_ModbusData[29] = STATEDATA1_JF.Bits.WdwPosition;
	       	gu8_ModbusData[30] = STATEDATA1_JF.Bits.WdwReverse;
	       	gu8_ModbusData[31] = STATEDATA1_JF.Bits.LocalSwStatus;
	       	gu8_ModbusData[32] = STATEDATA1_JF.Bits.WdwErr;
			break;
		case MOTOR_GSB:
			STATEDATA2_GSB.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_GSB.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[29] = STATEDATA2_GSB.Bits.WdwPosition;
	       	gu8_ModbusData[30] = STATEDATA2_GSB.Bits.APinch_decalibrated;
	       	gu8_ModbusData[31] = STATEDATA2_GSB.Bits.LocalSwStatus;
	       	gu8_ModbusData[32] = STATEDATA2_GSB.Bits.MovingStatus;
			break;
		case MOTOR_TM:
			STATEDATA2_TM.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_TM.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA2_TM.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	gu8_ModbusData[29] = STATEDATA2_TM.Bits.WdwPosition;
	       	gu8_ModbusData[30] = STATEDATA2_TM.Bits.APinch_decalibrated;
	       	gu8_ModbusData[31] = STATEDATA2_TM.Bits.LocalSwStatus;
	       	//ModbusData[32] = STATEDATA2_TM.Bits.MovingStatus;
			break;
		case MOTOR_SQ:
			STATEDATA_SQ.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA_SQ.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA_SQ.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	STATEDATA_SQ.StateData[3] = LIN_RX_FRAME.gu8_Data[3];
	       	gu8_ModbusData[29] = STATEDATA_SQ.Bits.LIN_WdwPosition;
	       	gu8_ModbusData[30] = STATEDATA_SQ.Bits.LIN_WdwErr_AntiPinch;
	       	gu8_ModbusData[31] = STATEDATA_SQ.Bits.LIN_WindowSTS_SPW;
	       	gu8_ModbusData[32] = STATEDATA_SQ.Bits.LIN_WdwErr_Thermal;
	       	//ModbusData[33] = STATEDATA_SQ.Bits.ERR_RESP_SPW;
	       	break;
	       case MOTOR_S111:
	       	STATEDATA2_S111.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_S111.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	break;
	}
}

///////////////////////////////////////////////////////////////////////////////
void Move_RR_Data(void)
{
	switch(gu8_ModbusData[MD_MODEL_ADDR])
	{
		case MOTOR_HB:
			STATEDATA_HB.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA_HB.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[33] = STATEDATA_HB.Bits.WdwPosition;
	       	gu8_ModbusData[34] = STATEDATA_HB.Bits.WdwReverse;
	       	gu8_ModbusData[35] = STATEDATA_HB.Bits.LocalSwStatus;
	       	gu8_ModbusData[36] = STATEDATA_HB.Bits.WdwErr;
			break;
		case MOTOR_JF:
			STATEDATA1_JF.StateData = LIN_RX_FRAME.gu8_Data[0];
			//STATEDATA.StateData[1] = LIN_RX_FRAME.data[1];
	       	gu8_ModbusData[33] = STATEDATA1_JF.Bits.WdwPosition;
	       	gu8_ModbusData[34] = STATEDATA1_JF.Bits.WdwReverse;
	       	gu8_ModbusData[35] = STATEDATA1_JF.Bits.LocalSwStatus;
	       	gu8_ModbusData[36] = STATEDATA1_JF.Bits.WdwErr;
			break;
		case MOTOR_GSB:
			STATEDATA2_GSB.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_GSB.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	gu8_ModbusData[33] = STATEDATA2_GSB.Bits.WdwPosition;
	       	gu8_ModbusData[34] = STATEDATA2_GSB.Bits.APinch_decalibrated;
	       	gu8_ModbusData[35] = STATEDATA2_GSB.Bits.LocalSwStatus;
	       	gu8_ModbusData[36] = STATEDATA2_GSB.Bits.MovingStatus;
			break;
		case MOTOR_TM:
			STATEDATA2_TM.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_TM.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA2_TM.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	gu8_ModbusData[33] = STATEDATA2_TM.Bits.WdwPosition;
	       	gu8_ModbusData[34] = STATEDATA2_TM.Bits.APinch_decalibrated;
	       	gu8_ModbusData[35] = STATEDATA2_TM.Bits.LocalSwStatus;
	       	//ModbusData[36] = STATEDATA2_TM.Bits.MovingStatus;
			break;
		case MOTOR_SQ:
			STATEDATA_SQ.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA_SQ.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	STATEDATA_SQ.StateData[2] = LIN_RX_FRAME.gu8_Data[2];
	       	STATEDATA_SQ.StateData[3] = LIN_RX_FRAME.gu8_Data[3];
	       	gu8_ModbusData[33] = STATEDATA_SQ.Bits.LIN_WdwPosition;
	       	gu8_ModbusData[34] = STATEDATA_SQ.Bits.LIN_WdwErr_AntiPinch;
	       	gu8_ModbusData[35] = STATEDATA_SQ.Bits.LIN_WindowSTS_SPW;
	       	gu8_ModbusData[36] = STATEDATA_SQ.Bits.LIN_WdwErr_Thermal;
	       	break;
	       case MOTOR_S111:
	       	STATEDATA2_S111.StateData[0] = LIN_RX_FRAME.gu8_Data[0];
	       	STATEDATA2_S111.StateData[1] = LIN_RX_FRAME.gu8_Data[1];
	       	break;
	}
}
//////////////////////////////////////////////////////////////////////////
u8 LINCalcChecksum_New(u8 *data,u8 parity_id, u8  datalength)
{

	u32 	sum = parity_id;
    	u8 	i;

    	for(i = 0; i < datalength; i++)
    	{
        	sum += data[i];
        	if(sum&0xFF00) sum = (sum & 0x00FF) + 1;      // Add carry                          
    	}
    	sum ^= 0x00FF;
    
    	return((u8)sum);
}
void LINSetState(LIN_state state)
{
	LIN_RX_FRAME.g_State = state;
}
LIN_state LINCheckState(void)
{

  return(LIN_RX_FRAME.g_State);

}
u8 LINSendMsg_New(u8 master, u8 send_data, LIN_message msg,u8 datalength)
{

	u8 check_sum, parity_id=0, i;

    	//if(rx[lin_num].state != IDLE)
    	//return(FALSE);
    	gu8_LinDataLength = datalength;
  
    	LIN_RX_FRAME.gu8_Error = 0;
  
    	if(master) 
    	{
       	 // Sends breack field
       	 LIN_RX_FRAME.g_State= _BREAK;
        	if(!LINSendChar(TRUE, 0x00)) return(FALSE);
        	gu8_LinTxStatue = _BREAK;
        	// Check breack sending
        	if(!LINCheckSend_New(_BREAK, 0x00,datalength)) return(FALSE);    
    
        	// Sends synch field
        	LIN_RX_FRAME.g_State = SYNCH;
        	if(!LINSendChar(FALSE, 0x55)) return(FALSE);
        	// Check synch sending
        	if(!LINCheckSend_New(SYNCH, 0x55,datalength))  return(FALSE);
    
        	parity_id=LINCalcParity(msg.gu8_Identifier);
        	// Sends protected identifier field
        	LIN_RX_FRAME.g_State = PROTECTED_IDENTIFIER;
        	if(!LINSendChar(FALSE, parity_id)) return(FALSE);
        	// Check protected identifier sending
        	if(!LINCheckSend_New(PROTECTED_IDENTIFIER, parity_id,datalength)) return(FALSE);
    	}
    	if (send_data)
    	{
	    	LIN_RX_FRAME.g_State = DATA;
        	for(i=0; i < datalength; i++) 
        	{
            		// Send data field 
            		if(!LINSendChar(FALSE, msg.gu8_DataField[i])) return(FALSE);
            
            		// Check data sending
            		if(!LINCheckSend_New(DATA, msg.gu8_DataField[i],datalength)) return(FALSE); 
        	}
        	check_sum = LINCalcChecksum(msg.gu8_DataField, parity_id, datalength);
        	//check_sum = 0x6a;
        	// Send checksum field
        	LIN_RX_FRAME.g_State = CHECKSUM;
        	if(msg.gu8_Identifier == 0x3C)check_sum= 0x00;//when sleep mode
        	if(!LINSendChar(FALSE, check_sum)) return(FALSE);
        
        	// Check checksum sending
        	if(!LINCheckSend_New(CHECKSUM, check_sum,datalength)) return(FALSE);
        
        	LIN_RX_FRAME.g_State = IDLE;
    	} 
	else 
    	{
      		LIN_RX_FRAME.g_State = DATA;
    	}
    	return(TRUE);   
}

u8 LINSendChar(u8 brk, u8 ch)
{
    //Wait until transmit data registry is empty (TDRE=1)
    //while(!(SCI1SR1&0x80));
    
    // If breack field, transmit one breack character (13-14 bits of dominant value) 
    gu8_LinByteIn = FALSE;
    if(brk) 
    {
//        SCI1CR2 |= 0x01;
//        SCI1CR2 &= ~0x01;
	Uart1_SendBreak();
    }
    else 
    {
//        SCI1DRL = ch;
	Uart1_SendByte(ch);
    }
    
    return(TRUE);
  
}
u8 LINCheckSend_New(LIN_state status, u8 val, u8 datalength)
{
	u32 cnt = 0;

	while(gu8_LinByteIn==FALSE)
	{
		cnt++;
    		if(cnt>65530)LIN_RX_FRAME.gu8_Error = 1;
        	if(LIN_RX_FRAME.gu8_Error) 	return(FALSE);
	}
	
	switch(status)
	{
		case  _BREAK:
			break;
		case SYNCH:
			break;
		case PROTECTED_IDENTIFIER:
			break;
		case DATA:
			break;
		case CHECKSUM:
			break;
	}

	return(TRUE); 
}
u8 LINCalcParity(u8 id)
{
    u8 parity, p0,p1;
  
    parity=id;
    p0=(BIT(parity,0)^BIT(parity,1)^BIT(parity,2)^BIT(parity,4))<<6;
    p1=(~(BIT(parity,1)^BIT(parity,3)^BIT(parity,4)^BIT(parity,5)))<<7;
    parity|=(p0|p1);
    
    return parity;
}
u8 LINCalcChecksum(u8 *data, u8 parity_id, u8 datalength)
{

    u32 sum = parity_id;//0;
    u8 i;

    for(i = 0; i < datalength; i++)
    {
        sum += data[i];
        if(sum&0xFF00) sum = (sum & 0x00FF) + 1;      // Add carry                         
        
    }
    sum ^= 0x00FF;
    
    return((u8)sum);
  
}


/*******************************************************************************
* Function Name  : Variable_Initial
* Description    : Led data out of 8 bit
* Input          : void
* Output         : void
* Return         : void
*******************************************************************************/
void Variable_Initial( void )
{
	
	
	
}
/*******************************************************************************
* Function Name  : System_Init
* Description    : Initializes the System application.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void System_Init(void)
{
	/* RCC system reset(for debug purpose) */
	RCC_DeInit();

	/* Enable HSE */
	RCC_HSEConfig(RCC_HSE_ON);

	/* Wait till HSE is ready */
	HSEStartUpStatus = RCC_WaitForHSEStartUp();

	if(HSEStartUpStatus == SUCCESS)
	{
	    	/* HCLK = SYSCLK */
	    	RCC_HCLKConfig(RCC_SYSCLK_Div1); 
	  
	    	/* PCLK2 = HCLK */
	    	RCC_PCLK2Config(RCC_HCLK_Div1); 
	
	    	/* PCLK1 = HCLK/4 */
	    	RCC_PCLK1Config(RCC_HCLK_Div2);
	
	    	/* Enable Prefetch Buffer */
	    	FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

	    	/* Flash 2 wait state */
	    	FLASH_SetLatency(FLASH_Latency_2);
	
	    	/* PLLCLK = 8MHz * 9 = 72 MHz */
	    	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
	
	    	/* Enable PLL */ 
	    	RCC_PLLCmd(ENABLE);
			
		/* Wait till PLL is ready */
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}

		/* Select PLL as system clock source */
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

		/* Wait till PLL is used as system clock source */
		while(RCC_GetSYSCLKSource() != 0x08)
		{
		}
	}
	
	/* Enable GPIO clock */
  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  	/* Enable GPIOA, GPIOB, GPIOC, GPIOD, GPIOE and AFIO clocks */
  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  	/* Enable GPIOA, GPIOB, GPIOC, GPIOD, GPIOE and AFIO clocks */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, ENABLE);
 
  	/* Enable UART clock */
  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);  
  	//RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);  

	/* Enable DMA1 clock */
  	//RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

  	/* Enable ADC1 and GPIOC clock */
  	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

	/* GPIO Configuration */
	GPIO_Config();

	/* USRT Configuration */
	USART_Configuration();


	/* Interrupt Configuration */
	//INT_Configuration();
  
	NVIC_Configuration();

	SysTick_Configuration();
	
}

void GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
/*
	
  		///////////////////////////////////////////////////////////////////////
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3  | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6  | GPIO_Pin_7;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOG, &GPIO_InitStructure);
  	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11  | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14  | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOG, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3  | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6  | GPIO_Pin_7;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOF, &GPIO_InitStructure);
  	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11  | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14  | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOF, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3  | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6  | GPIO_Pin_7;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOE, &GPIO_InitStructure);
  	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11  | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14  | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOE, &GPIO_InitStructure);

	
  	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11  | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14  | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOD, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3  | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6  | GPIO_Pin_7;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOC, &GPIO_InitStructure);
  	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11  | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14  | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOC, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_5 | GPIO_Pin_9  | GPIO_Pin_12 | GPIO_Pin_13;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5  | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8  | GPIO_Pin_11 | GPIO_Pin_12;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// Encoder A,B
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	// Configure USART1 Tx as alternate function push-pull
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;  // PA.09 USART1.TX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
 
	// Configure USART1 Rx as input floating 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; // PA.10 USART1.RX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	// Configure USART2 Tx as alternate function push-pull 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;  // PA.09 USART1.TX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
 
	// Configure USART2 Rx as input floating 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; // PA.10 USART1.RX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// Configure USART3 Tx as alternate function push-pull 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;  // PA.09 USART1.TX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
 
	// Configure USART3 Rx as input floating 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11; // PA.10 USART1.RX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);


	// Configure PB.0 (ADC Channel8,  as analog inputs 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// led 
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOE, &GPIO_InitStructure);
	// led Controller
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3  | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 ;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOD, &GPIO_InitStructure);
	// sub rs485 direction
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 ;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOD, &GPIO_InitStructure);
	// READY,START, STOP,
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9| GPIO_Pin_10 | GPIO_Pin_11;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOD, &GPIO_InitStructure);
  	// Configure PC.0 (ADC Channel8,  as analog inputs
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  	GPIO_Init(GPIOC, &GPIO_InitStructure);
  	// TRIGGER OUT, TRIGGER END Output
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_4;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);
  	// TRIGGER IN as input floating
 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);
  	// Test key input
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	// PC rs485 direction
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 ;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOE, &GPIO_InitStructure);
  */

///////////////////////////////////////////////////////////////////////
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_5 | GPIO_Pin_6  | GPIO_Pin_7 | GPIO_Pin_8;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);

  	// Configure USART1 Tx as alternate function push-pull
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;  // PA.09 USART1.TX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
 
	// Configure USART1 Rx as input floating 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; // PA.10 USART1.RX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	// Configure USART2 Tx as alternate function push-pull 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;  // PA.09 USART1.TX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
 
	// Configure USART2 Rx as input floating 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; // PA.10 USART1.RX
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4  | GPIO_Pin_5 | GPIO_Pin_6  | GPIO_Pin_7;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOE, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 |GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12  | GPIO_Pin_13 | GPIO_Pin_14  | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOE, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5  | GPIO_Pin_6 | GPIO_Pin_7;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOD, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 |GPIO_Pin_10 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14  | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOD, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6  | GPIO_Pin_7 | GPIO_Pin_8;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_15;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  	GPIO_Init(GPIOC, &GPIO_InitStructure);

  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_1 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8  | GPIO_Pin_9 | GPIO_Pin_13;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOC, &GPIO_InitStructure);
} 

/*******************************************************************************
* Function Name  : SysTick_Configuration
* Description    : Configure a SysTick Base time to 10 ms.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SysTick_Configuration(void)
{
  	/* Setup SysTick Timer for 10 msec interrupts  */
  	//if (SysTick_Config(SystemCoreClock / 100))
  	//{ 
    		/* Capture error */ 
   	// while (1);
 	// }

  	/* Setup SysTick Timer for 1000 usec interrupts  */
  	if (SysTick_Config(72000000 / 1000))
  	{ 
    		/* Capture error */ 
    		while (1);
  	}
  
 	/* Configure the SysTick handler priority */
  	NVIC_SetPriority(SysTick_IRQn, 0x0);
}


/*******************************************************************************
* Function Name  : INT_Configuration
* Description    : Interrupt setting location
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void INT_Configuration(void)
{ 
  	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  	TIM_OCInitTypeDef        TIM_OCInitStructure;

  	/* Set the Vector Table base address at 0x08000000 */
  	NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x00);

  	/* TIM2 used for timing, the timing period depends on wav file sample rate */
  	TIM_TimeBaseStructure.TIM_Prescaler = 0x00;    		/* TIM2CLK = 24 MHz */
  	TIM_TimeBaseStructure.TIM_Period = 24000;			// 1.0msec
  	TIM_TimeBaseStructure.TIM_ClockDivision = 0x0;
  	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

  	/* Output Compare Inactive Mode configuration: Channel1 */
  	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_Inactive;
  	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  	TIM_OCInitStructure.TIM_Pulse = 0x0;
  	TIM_OC1Init(TIM2, &TIM_OCInitStructure);

  	TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Disable);

  	/* Start TIM2 */
  	TIM_Cmd(TIM2, ENABLE);

  	/* Enable TIM2 update interrupt */
  	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

}

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configure the nested vectored interrupt controller.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{
  	NVIC_InitTypeDef NVIC_InitStructure;
	 
	/* Configure the Priority Group to 2 bits */
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

/*
	// Enable the EXTI0 Interrupt 
    	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
*/
    
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
/*
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
*/
}


/*******************************************************************************
* Function Name  : ALive_Cpu
* Description    : Configurate the USART INT
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ALive_Cpu(void)
{		
	if(!gu16ALive_Cpu_Dly)
	{				
		LED1_TOGGLE;
		LED2_TOGGLE;
		LED3_TOGGLE;
		LED4_TOGGLE;
		gu16ALive_Cpu_Dly = 100;
	}
}
/*******************************************************************************
* Function Name  : Model_Select
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Model_Select(u8 Motor_Model)
{
	switch(Motor_Model)
	{
		case MOTOR_HB:
			gu8_Cmd_Length = 8;
			gu8_FL_Length = 6;
			gu8_FR_Length = 6;
			gu8_RL_Length = 6;
			gu8_RR_Length = 6;

			gu8_Cmd_Delay = 10;// 20 x500us = 10ms
			gu8_FL_Delay = 10;
			gu8_FR_Delay = 10;
			gu8_RL_Delay = 10;
			gu8_RR_Delay = 10;
		 	break;
	  	case MOTOR_JF:
	  		gu8_Cmd_Length = 4;
			gu8_FL_Length = 2;
			gu8_FR_Length = 2;
			gu8_RL_Length = 1;
			gu8_RR_Length = 1;

			gu8_Cmd_Delay = 9;//10;// 20 x500us = 10ms
			gu8_FL_Delay = 4;//5;
			gu8_FR_Delay = 4;//5;
			gu8_RL_Delay = 4;//5;
			gu8_RR_Delay = 4;//5;
			break;
		case MOTOR_GSB:
			gu8_Cmd_Length = 3;
			gu8_FL_Length = 2;
			gu8_FR_Length = 2;
			gu8_RL_Length = 2;
			gu8_RR_Length = 2;

			gu8_Cmd_Delay = 10;// 20 x500us = 10ms
			gu8_FL_Delay = 5;
			gu8_FR_Delay = 5;
			gu8_RL_Delay = 5;
			gu8_RR_Delay = 5;
			break;
		case MOTOR_TM:
			gu8_Cmd_Length = 4;
			gu8_FL_Length = 3;
			gu8_FR_Length = 3;
			gu8_RL_Length = 3;
			gu8_RR_Length = 3;

			gu8_Cmd_Delay = 10;// 20 x500us = 10ms
			gu8_FL_Delay = 5;
			gu8_FR_Delay = 5;
			gu8_RL_Delay = 5;
			gu8_RR_Delay = 5;
			break;
		case MOTOR_SQ:
			gu8_Cmd_Length = 8;
			gu8_FL_Length = 4;
			gu8_FR_Length = 4;
			gu8_RL_Length = 4;
			gu8_RR_Length = 4;

			gu8_Cmd_Delay = 20;// 20 x500us = 10ms
			gu8_FL_Delay = 20;
			gu8_FR_Delay = 20;
			gu8_RL_Delay = 20;
			gu8_RR_Delay = 20;
			break;
		case MOTOR_S111:
			gu8_Cmd_Length = 8;
			gu8_FL_Length = 4;
			gu8_FR_Length = 2;
			gu8_RL_Length = 2;
			gu8_RR_Length = 2;

			gu8_Cmd_Delay = 20;// 20 x500us = 10ms
			gu8_FL_Delay = 20;
			gu8_FR_Delay = 10;
			gu8_RL_Delay = 10;
			gu8_RR_Delay = 10;
			break;
	}

}
void Lin_Model_Run(void)
{
  	u8 ch;
  	
	if(gu8_fRxEnable)
	 {
		if(gu16_Rx_Over_Tm == 0)
		{	
			gu8_iFront = 0;
			gu8_Rx_Test_Buf_Index = 0;
		}
	}
		
		
	  	if(gu8_fLinTxEnable)
	  	{
	  		if(gu16_LinTxDly==0)
		 	{
		 		ch = LIN_RX_FRAME.gu8_Protected_ID & 0x3F;
				switch(ch)
		       	{
		       	
		       		case 0x15:
		       			ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_Cmd_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_Cmd_LedDly = 3; // 1ms * 8 = 8
	       				}
		       			break;
	       			case 0x16:
	       				ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_FL_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_FL_LedDly = 5; // 1ms * 8 = 8
	       					FL_LED_ON;
	       					Move_FL_Data();
	       					gu8_FL_Connected = LIN_RX_DISCOUNT;
	       				}
	       				else 
	       				{
	       					if(gu8_FL_Connected) gu8_FL_Connected--;
	       				}
		       			break;
	       			case 0x17:
	       				ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_FR_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_FR_LedDly = 5; // 1ms * 8 = 8
	       					FR_LED_ON;
	       					Move_FR_Data();
	       					gu8_FR_Connected = LIN_RX_DISCOUNT;
	       				}
	       				else
	       				{
	       					if(gu8_FR_Connected)gu8_FR_Connected--;
	       				}
		       			break;                                            
	       			case 0x18:
	       				ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_RL_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_RL_LedDly = 5; // 1ms * 8 = 8
	       					RL_LED_ON;
	       					Move_RL_Data();
	       					gu8_RL_Connected = LIN_RX_DISCOUNT;
	       				}
	       				else
	       				{
	       					if(gu8_RL_Connected) gu8_RL_Connected--;
	       				}
		       			break;
	       			case 0x19:
	       				ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_RR_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_RR_LedDly = 5; // 1ms * 8 = 8
	       					RR_LED_ON;
	       					Move_RR_Data();
	       					gu8_RR_Connected = LIN_RX_DISCOUNT;
	       				}
	       				else
	       				{
	       					if(gu8_RR_Connected) gu8_RR_Connected--;
	       				}
		       			break;			
		       		}
	       		LINSetState(IDLE);
	              	// LIN ����� IDLE�������� üũ
		       	if(LINCheckState() == IDLE) 
	       		{
	           			MSG_SEND.gu8_Identifier = gu8_ID[gu8_ID_Index];         // LIN �޽��� ����ü�� ID���� 
		           		switch(gu8_ID[gu8_ID_Index])
	       	    		{
	           				case 0x15:
							gu16_LinTxDly = gu8_Cmd_Delay;// * 5;	// 200us x 5 = 1ms	       		
							Move_Command();
							(void)LINSendMsg_New(TRUE, TRUE, MSG_SEND, gu8_Cmd_Length);  // // LIN �޽��� ����
							//gu8_Cmd_LedDly = 3; // 1ms * 8 = 8
	       					//CMD_LED_ON;
	           					break;
		           			case 0x16:
							gu16_LinTxDly = gu8_FL_Delay ;//* 5;	// 200us x 5 = 1ms	       		
	       	    				(void)LINSendMsg_New(TRUE, FALSE, MSG_SEND, gu8_FL_Length);  // // LIN �޽��� ����
	           					break;
		           			case 0x17:
							gu16_LinTxDly = gu8_FR_Delay;// * 5;	// 200us x 5 = 1ms
	       	    				(void)LINSendMsg_New(TRUE, FALSE, MSG_SEND, gu8_FR_Length);  // // LIN �޽��� ����
	           					break;
		           			case 0x18:
							gu16_LinTxDly = gu8_RL_Delay;// * 5;	// 200us x 5 = 1ms
	       	   				(void)LINSendMsg_New(TRUE, FALSE, MSG_SEND, gu8_RL_Length);  // // LIN �޽��� ����
	           					break;
		           			case 0x19:
							gu16_LinTxDly = gu8_RR_Delay;// * 5;	// 200us x 5 = 1ms
	       	    				(void)LINSendMsg_New(TRUE, FALSE, MSG_SEND, gu8_RR_Length);  // // LIN �޽��� ����
		           				break;
	       	    		}
	       		}
	       		gu8_ID_Index++;
		       	if(gu8_ID_Index > 4)gu8_ID_Index=0;	       		
//		       	if(gu8_ID_Index > 5)gu8_ID_Index=0;	       		
	       	}
	       	
		}
		else
		{
			
		}
}
/*
void Model_Total(void)
{
  	u8 ch;
  	
	if(gu8_fRxEnable)
	 {
		if(gu16_Rx_Over_Tm == 0)
		{	
			gu8_iFront = 0;
			gu8_Rx_Test_Buf_Index = 0;
		}
	}
		
	  	if(gu8_fLinTxEnable)
	  	{
	  		if(gu16_LinTxDly==0)
		 	{
		 		ch = LIN_RX_FRAME.gu8_Protected_ID & 0x3F;
				switch(ch)
		       	{
		       	
		       		case 0x15:
		       			ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_Cmd_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_Cmd_LedDly = 3; // 1ms * 8 = 8
//	       					CMD_LED_ON;
	       				}
		       			break;
	       			case 0x16:
	       				ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_FL_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_FL_LedDly = 5; // 1ms * 8 = 8
	       					FL_LED_ON;
//	       					EXOUT1_ON;
//	       					FL_Data_Move();
	       					gu8_FL_Connected = TRUE;
	       				}
	       				else 
	       				{
	       					gu8_FL_Connected = FALSE;
	       				}
		       			break;
	       			case 0x17:
	       				ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_FR_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_FR_LedDly = 5; // 1ms * 8 = 8
	       					FR_LED_ON;
//	       					EXOUT2_ON;
//	       					FR_Data_Move();
	       					gu8_FR_Connected = TRUE;
	       				}
	       				else
	       				{
	       					gu8_FR_Connected = FALSE;
	       				}
		       			break;                                            
	       			case 0x18:
	       				ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_RL_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_RL_LedDly = 5; // 1ms * 8 = 8
	       					RL_LED_ON;
//	       					EXOUT3_ON;
//	       					RL_Data_Move();
	       					gu8_RL_Connected = TRUE;
	       				}
	       				else
	       				{
	       					gu8_RL_Connected = FALSE;
	       				}
		       			break;
	       			case 0x19:
	       				ch = LINCalcChecksum_New(LIN_RX_FRAME.gu8_Data, LIN_RX_FRAME.gu8_Protected_ID, gu8_RR_Length);
	       				if(ch == LIN_RX_FRAME.gu8_Check)
	       				{
	       					gu8_RR_LedDly = 5; // 1ms * 8 = 8
	       					RR_LED_ON;
//	       					EXOUT4_ON;
//	       					RR_Data_Move();
	       					gu8_RR_Connected = TRUE;
	       				}
	       				else
	       				{
	       					gu8_RR_Connected = FALSE;
	       				}
		       			break;			
		       		}
	       		LINSetState(IDLE);
	              	// LIN ����� IDLE�������� üũ
		       	if(LINCheckState() == IDLE) 
	       		{
	           			MSG_SEND.gu8_Identifier = gu8_ID[gu8_ID_Index];         // LIN �޽��� ����ü�� ID���� 
		           		switch(gu8_ID[gu8_ID_Index])
	       	    		{
	           				case 0x15:
							gu16_LinTxDly = gu8_Cmd_Delay-1;//  5;	// 200us x 5 = 1ms	       		
							Command_Move();
							(void)LINSendMsg_New(TRUE, TRUE, MSG_SEND, gu8_Cmd_Length);  // // LIN �޽��� ����
							//gu8_Cmd_LedDly = 3; // 1ms * 8 = 8
	       					//CMD_LED_ON;
	           					break;
		           			case 0x16:
							gu16_LinTxDly = gu8_FL_Delay-1;//  5;	// 200us x 5 = 1ms	       		
	       	    				(void)LINSendMsg_New(TRUE, FALSE, MSG_SEND, gu8_FL_Length);  // // LIN �޽��� ����
	           					break;
		           			case 0x17:
							gu16_LinTxDly = gu8_FR_Delay-1;//  5;	// 200us x 5 = 1ms
	       	    				(void)LINSendMsg_New(TRUE, FALSE, MSG_SEND, gu8_FR_Length);  // // LIN �޽��� ����
	           					break;
		           			case 0x18:
							gu16_LinTxDly = gu8_RL_Delay -1;// 5;	// 200us x 5 = 1ms
	       	   				(void)LINSendMsg_New(TRUE, FALSE, MSG_SEND, gu8_RL_Length);  // // LIN �޽��� ����
	           					break;
		           			case 0x19:
							gu16_LinTxDly = gu8_RR_Delay -1;// 5;	// 200us x 5 = 1ms
	       	    				(void)LINSendMsg_New(TRUE, FALSE, MSG_SEND, gu8_RR_Length);  // // LIN �޽��� ����
		           				break;
	       	    		}
	       		}
	       		gu8_ID_Index++;
		       	if(gu8_ID_Index > 4)gu8_ID_Index=0;	       		
//		       	if(gu8_ID_Index > 5)gu8_ID_Index=0;	       		
	       	}
	       	
		}
		else
		{
			
		}
}
*/

/***********************************************************************
	Function Name  : Led_Process_Task
	Parameter	   : void
	Returned Value : void
	Comments	   : Led Process task
***********************************************************************/
void Led_Process_Task(void)
{
	
	if(!gu8_FL_LedDly )
	{
		FL_LED_OFF;
	}
	
	if(!gu8_FR_LedDly)
	{
		FR_LED_OFF;
	}
	
	if(!gu8_RL_LedDly)
	{
		RL_LED_OFF;
	}
	
	if(!gu8_RR_LedDly)
	{
		RR_LED_OFF;
	}
	
}
/***********************************************************************
	Function Name  : 
 	Parameter      : void
 	Returned Value : void
 	Comments       : 
***********************************************************************/
u8 	AsciiToHex(u8 H_nibble, u8 L_nibble)
{
	u8	 hex;
	if((0x30 <=H_nibble) && ( H_nibble <= 0x39))
	{
		H_nibble= H_nibble - 0x30;
	}
	else
	{
		
		H_nibble= H_nibble - 'A' + 10;
	}
	hex = H_nibble<< 4;

	if((0x30 <=L_nibble) && ( L_nibble <= 0x39))
	{
		L_nibble= L_nibble - 0x30;
	}
	else
	{
		
		L_nibble= L_nibble - 'A' + 10;
	}
	hex = hex | (L_nibble & 0x0F);

	return hex;
}

/***********************************************************************
	Function Name  : 
 	Parameter      : void
 	Returned Value : void
 	Comments       : 
***********************************************************************/
void GetLRC_Rx(u8 *H_LRC, u8 *L_LRC)
{
	u8 H_Nibble;
       u8 L_Nibble;
       u8 value;
       u8 total;
       u8 i;

       total = 0;
	for (i = 1; i < (gu8_iRear - 4); )
	{
		H_Nibble = gu8_RxBuf[i++];
		L_Nibble = gu8_RxBuf[i++];
		value = AsciiToHex(H_Nibble, L_Nibble);
		total +=value;
	}
	total = (u8)(255 - total+1);

	value = total >>4;
	*H_LRC = ASCII[value];
	value = total & 0x0F;
	*L_LRC = ASCII[value];
}
/***********************************************************************
	Function Name  : 
 	Parameter      : void
 	Returned Value : void
 	Comments       : 
***********************************************************************/
void GetLRC_Tx(u8 *H_LRC, u8 *L_LRC, u8 Length)
{
	u8 H_Nibble;
       u8 L_Nibble;
       u8 value;
       u8 total;
       u8 i;

       total = 0;
	for (i = 1; i < Length; )
	{
		H_Nibble = gu8_TxBuf[i++];
		L_Nibble = gu8_TxBuf[i++];
		value = AsciiToHex(H_Nibble, L_Nibble);
		total +=value;
	}
	total = (u8)(255 - total+1);

	value = total >>4;
	*H_LRC = ASCII[value];
	value = total & 0x0F;
	*L_LRC = ASCII[value];
}

/***********************************************************************
	Function Name  : 
 	Parameter      : void
 	Returned Value : void
 	Comments       : 
***********************************************************************/
void Com_PcToMaster(void)
{
	u8 H_Nibble, L_Nibble;
	u8 StartAddr;
	u8 DataCount;
	u8 i;
	u8 FunctionCode;

	
	if(!gu8_fReceive)return;

	gu8_fReceive = 0;
	
	GetLRC_Rx(&H_Nibble, &L_Nibble);
	if((H_Nibble != gu8_RxBuf[gu8_iRear-4]) || (L_Nibble != gu8_RxBuf[gu8_iRear-3]))
	{
		for(i=0;i<60;i++)gu8_RxBuf[i] = 0x00;
		return;
	}

	StartAddr = AsciiToHex(gu8_RxBuf[7], gu8_RxBuf[8]);
	
	FunctionCode = AsciiToHex(gu8_RxBuf[3], gu8_RxBuf[4]);
	if(StartAddr)StartAddr--;
	switch(FunctionCode)
	{
		case 0x03:	//Read Holding Register
			DataCount = AsciiToHex(gu8_RxBuf[11], gu8_RxBuf[12]);
			if(DataCount > 8)return; //read/write  Max Count

			for(i=0;i<50;i++)gu8_TxBuf[i] = 0x30;//tx buffer clear
			gu8_TxBuf[0] = 0x3A; 	//stx
			gu8_TxBuf[1] = 0x30;	//slave address
			gu8_TxBuf[2] = 0x31;
			gu8_TxBuf[3] = 0x30;	//function code
			gu8_TxBuf[4] = 0x33;
			gu8_Temp = DataCount *  2;
			H_Nibble = gu8_Temp >> 4;
			L_Nibble = gu8_Temp & 0x0F;
			gu8_TxBuf[5] = ASCII[H_Nibble];
			gu8_TxBuf[6] = ASCII[L_Nibble];
			
			gu8_Temp = 0;
			for(i=StartAddr;i<(StartAddr+DataCount);i++)
			{
				gu8_TxBuf[(gu8_Temp *4)+7] = 0x30;
				gu8_TxBuf[(gu8_Temp *4)+8] = 0x30;
				gu8_TxBuf[(gu8_Temp *4)+9] = ASCII[gu8_ModbusData[i]/16];
				gu8_TxBuf[(gu8_Temp *4)+10] = ASCII[gu8_ModbusData[i]%16];
				gu8_Temp++;
			}
			gu8_Temp = (gu8_Temp*4)+10-3;
			GetLRC_Tx(&H_Nibble, &L_Nibble, gu8_Temp);
			gu8_TxBuf[gu8_Temp++] = H_Nibble; 
			gu8_TxBuf[gu8_Temp++] = L_Nibble;
			gu8_TxBuf[gu8_Temp++] = 0x0D;
			gu8_TxBuf[gu8_Temp++] = 0x0A;
			gu8_TxBuf_Length = gu8_Temp;
			gu8_fTxDataEnable = 1;
			break;
		case 0x06:	//Write Single Register
			H_Nibble = gu8_RxBuf[11];
			L_Nibble = gu8_RxBuf[12];
			gu8_ModbusData[StartAddr] = AsciiToHex(H_Nibble, L_Nibble);
			for(i=0;i<13;i++)gu8_TxBuf[i] = gu8_RxBuf[i];
			gu8_Temp = 13;
			GetLRC_Tx(&H_Nibble, &L_Nibble, gu8_Temp);
			gu8_TxBuf[gu8_Temp++] = H_Nibble; 
			gu8_TxBuf[gu8_Temp++] = L_Nibble;
			gu8_TxBuf[gu8_Temp++] = 0x0D;
			gu8_TxBuf[gu8_Temp++] = 0x0A;
			gu8_TxBuf_Length = gu8_Temp;
			gu8_fTxDataEnable = 1;
			break;
		case 0x10:	// Write Multiple Register
			DataCount = AsciiToHex(gu8_RxBuf[11], gu8_RxBuf[12]);
			if(DataCount > 8)return; //read/write  Max Count

			gu8_Temp = 0;
			for(i=StartAddr;i<(StartAddr+DataCount);i++)
			{
				H_Nibble = gu8_RxBuf[(gu8_Temp *4)+17];
				L_Nibble = gu8_RxBuf[(gu8_Temp *4)+18];
				
				gu8_ModbusData[i] = AsciiToHex(H_Nibble, L_Nibble);
				//if(i != 40)Write_Fun[i-1]( );	// 40 => model select
				gu8_Temp++;
			}
			for(i=0;i<13;i++)gu8_TxBuf[i] = gu8_RxBuf[i];
			gu8_Temp = 13;
			GetLRC_Tx(&H_Nibble, &L_Nibble, gu8_Temp);
			gu8_TxBuf[gu8_Temp++] = H_Nibble; 
			gu8_TxBuf[gu8_Temp++] = L_Nibble;
			gu8_TxBuf[gu8_Temp++] = 0x0D;
			gu8_TxBuf[gu8_Temp++] = 0x0A;
			gu8_TxBuf_Length = gu8_Temp;
			gu8_fTxDataEnable = 1;
			break;
	}
	
	for(i=0;i<60;i++)gu8_RxBuf[i] = 0x00; // Rx Clear
}
void Com_MasterToPc( void )
{
	if(!gu8_fTxDataEnable)return;
	
	Send_Pc(gu8_TxBuf,  gu8_TxBuf_Length);
	gu8_fTxDataEnable = 0;
}
/*******************************************************************************
* Function Name  : Send_Pc
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Send_Pc(u8 buffer[], u8 size)
{
    int i=0;

    gu8_Usart2_Tx_Buf_Index = 0;
    gu8_Usart2_Tx_Data_Length = size;

    for (i=0; i < size; ++i)
    {
        gu8_Usart2_Tx_Buf[ i] = buffer[ i];
    }             

    USART_ITConfig(USART2, USART_IT_TXE, ENABLE);
}

/***********************************************************************
	Function Name  : Com_Main_To_Dis
 	Parameter      : void
 	Returned Value : void
 	Comments       : Communication Main to Sub
***********************************************************************/
//void Com_Main_To_Sub_Tx( void )
//{
	
//}

/***********************************************************************
	Function Name  : Com_Sub_To_Main
 	Parameter      : void
 	Returned Value : void
 	Comments       : Communication Dis to Main
***********************************************************************/
//void Com_Master_To_Sub_Tx( void )
//{
		
//}
/***********************************************************************
	Function Name  : Com_Pc_To_Main
 	Parameter      : void
 	Returned Value : void
 	Comments       : Communication Pc to Main
***********************************************************************/
//void Com_Master_To_Sub_Rx( void )
//{
	
	
//}
/***********************************************************************
	Function Name  : Com_Main_To_Pc
 	Parameter      : void
 	Returned Value : void
 	Comments       : Communication Main to Pc
***********************************************************************/
//void Com_Main_To_Pc_Tx( void )
//{
	
//}
/***********************************************************************
	Function Name  : 
 	Parameter      : void
 	Returned Value : void
 	Comments       : 
***********************************************************************/
void LINReceiverHandler(u8  Is_Break) 
{  
	if(!LINGetChar_New(Is_Break)) 
  	{
		LIN_RX_FRAME.gu8_Error = 1;
    		LIN_RX_FRAME.g_State = IDLE;
	}	
}
/***********************************************************************
	Function Name  : 
 	Parameter      : void
 	Returned Value : void
 	Comments       : 
***********************************************************************/
u8 LINGetChar_New(u8 Is_Break)
{ 
     u8 ch=0;

	ch = (u8)USART_ReceiveData(USART1);
    	//mLinDataLength = 4;
   	if(LIN_RX_FRAME.g_State == IDLE)
   	{
   		
            	 
   	}
    	else if(LIN_RX_FRAME.g_State == _BREAK)
    	{
	    	gu8_Buf_Test_Index =0;
    		LIN_RX_FRAME.gu8_Break= ch;
    		gu8_Buf_Test[gu8_Buf_Test_Index++] =ch;
    		gu8_LinByteIn = TRUE;
    	}
    	else if(LIN_RX_FRAME.g_State == SYNCH)
    	{
    		gu8_Buf_Test[gu8_Buf_Test_Index++] = ch;
            	LIN_RX_FRAME.gu8_Protected_ID = ch;
            	gu8_LinByteIn = TRUE;
    	}
    	else if(LIN_RX_FRAME.g_State ==PROTECTED_IDENTIFIER)
    	{
    		 gu8_Buf_Test[gu8_Buf_Test_Index++] = ch;
            	 LIN_RX_FRAME.gu8_Protected_ID = ch;
            	 gu8_LinRxDataCounter = 0;
            	 gu8_LinByteIn = TRUE;
    	}
    	else if(LIN_RX_FRAME.g_State == DATA)
    	{
    		if(gu8_LinDataLength>gu8_LinRxDataCounter)
    		{
	    		LIN_RX_FRAME.gu8_Data[gu8_LinRxDataCounter++] = ch;
            		gu8_Buf_Test[gu8_Buf_Test_Index++] = ch;
            		gu8_LinByteIn = TRUE;
            		if(gu8_LinDataLength==gu8_LinRxDataCounter)	LIN_RX_FRAME.g_State =  CHECKSUM;
            	}
    	}
    	else if(LIN_RX_FRAME.g_State ==  CHECKSUM)
    	{
		LIN_RX_FRAME.gu8_Check = ch;
    		gu8_Buf_Test[gu8_Buf_Test_Index++] = ch;
    		gu8_LinByteIn = TRUE;
    		LIN_RX_FRAME.g_State = IDLE;
//		if(Is_Break!=FALSE)                  return(FALSE);
    	}
    	if(gu8_Buf_Test_Index>39)gu8_Buf_Test_Index=0;
    	return(TRUE);  
}

void Board_Control(void)
{
	//u8 Data = ModbusData[40];

	Selected_Read_Signal(gu8_ModbusData[MD_SIGNAL_SELECT_ADDR]);
//	Chsel_Value_Set(gu8_ModbusData[MD_CHANNEL_SELECT_ADDR]);
	Chsel_Value_Set();
	JF_SW_Set(gu8_ModbusData[MD_JF_SW_ADDR]);

	Enable_Set( gu8_ModbusData[MD_ENABLE]);
	Power_Set( gu8_ModbusData[MD_POWER]);
	Cylinder_Set(0,gu8_ModbusData[MD_CYLINDER]);
	Lin_Slave_Type();
	Extra_Port_LVL1_SIG1();
}
// ���� �׷����� �׸��� ���� ȸ�� ���� �Լ�
void Extra_Port_LVL1_SIG1(void)
{
	if(gu8_ModbusData[MD_LVL_IN_SEL1] == 0)
	{
		LVLIN_SEL1_SET;
		LVLIN_SELX_CLR;
	}
	else
	{
		LVLIN_SEL1_CLR;
		LVLIN_SELX_SET;
	}

	if(gu8_ModbusData[MD_SIG_IN_SEL1] == 0)
	{
		SIGIN_SEL1_SET;
		SIGIN_SELX_CLR;
	}
	else
	{
		SIGIN_SEL1_CLR;
		SIGIN_SELX_SET;
	}
}
void Selected_Read_Signal(u8 Selected_Signal)
{
	u16 Value = 0;

	if(gu8_Selected_Signal == Selected_Signal)return;
	else
	{
		if(gu8_Signal_Select_Dly_Enable==0)
		{
			GPIO_Write(GPIOE, 0);
			SIGIN_CTLX_CLR;
			LVLIN_CTLX1_CLR;
			gu8_Signal_Select_Dly_Enable = 1;
			gu8_Signal_Select_Dly = 50;
		}
		else
		{
			if(gu8_Signal_Select_Dly)return;
		}
	}


	if(Selected_Signal == 0)
	{
		GPIO_Write(GPIOE, 0);
		SIGIN_CTLX_CLR;
		LVLIN_CTLX1_CLR;
	}
	else if(0<Selected_Signal && Selected_Signal < 17)
	{	
		sbit(Value, Selected_Signal-1);
		GPIO_Write(GPIOE, Value);

		SIGIN_CTLX_CLR;
		LVLIN_CTLX1_CLR;
	}
	else if(Selected_Signal == 17 )// SIG In Control 
	{
		GPIO_Write(GPIOE, 0);
		SIGIN_CTLX_SET;
		LVLIN_CTLX1_CLR;
	}
	else if(Selected_Signal == 18)// LVL In Control
	{
		GPIO_Write(GPIOE, 0);
		LVLIN_CTLX1_SET;
		SIGIN_CTLX_CLR;
	}
	gu8_Selected_Signal = Selected_Signal;
	gu8_Signal_Select_Dly_Enable = 0;
	
}
void Chsel_Value_Set()
{

//	if(gu8_Chsel_Value == Value)return;


	if(gu8_ModbusData[MD_ECU_TYPE] == ECU_P)
	{
		// ECU Type : P
		CHSEL_CTL1_OPEN;
		CHSEL_CTL2_OPEN;
		CHSEL_CTL3_OPEN;
		CHSEL_CTL4_OPEN;
		CHSEL_CTL5_OPEN;
		CHSEL_CTL6_OPEN;
	}
	else
	{
		// ECU Type : Q
		CHSEL_CTL1_CLOSE;
		CHSEL_CTL2_CLOSE;
		CHSEL_CTL3_CLOSE;
		CHSEL_CTL4_CLOSE;
		CHSEL_CTL5_CLOSE;
		CHSEL_CTL6_CLOSE;
	}
	
	
/*
	switch(Value)
	{
		case 1:
			CHSEL_CTL1_CLOSE;
			break;
		case 2:
			CHSEL_CTL2_CLOSE;
			break;
		case 3:
			CHSEL_CTL3_CLOSE;
			break;
		case 4:
			CHSEL_CTL4_CLOSE;
			break;
		case 5:
			CHSEL_CTL5_CLOSE;
			break;
		case 6:
			CHSEL_CTL6_CLOSE;
			break;
	}
*/
//	gu8_Chsel_Value = Value;
}
void JF_SW_Set(u8 Value)
{
	
	if(gu8_ModbusData[MD_SW1_SW2_SELECT]==0)	JFSW_SEL_CLR;
	else											JFSW_SEL_SET;
	
//	if(gu8_JF_SW_Value == Value)return;

	switch(Value)
	{
		case NONE:
			ANAL_DOWN_CLR;
			ANAL_UP_CLR;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_CLR;
			SW_UP_CTL_CLR;
			SW_AUTO_CTL_CLR;
			break;
		case ANAL_DOWN:
			ANAL_DOWN_SET;
			ANAL_UP_CLR;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_CLR;
			SW_UP_CTL_CLR;
			SW_AUTO_CTL_CLR;
			break;
		case ANAL_UP:
			ANAL_DOWN_CLR;
			ANAL_UP_SET;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_CLR;
			SW_UP_CTL_CLR;
			SW_AUTO_CTL_CLR;
			break;
		case ANAL_A_DOWN:
			ANAL_DOWN_CLR;
			ANAL_UP_CLR;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_SET;

			SW_DOWN_CTL_CLR;
			SW_UP_CTL_CLR;
			SW_AUTO_CTL_CLR;
			break;
		case ANAL_A_UP:
			ANAL_DOWN_CLR;
			ANAL_UP_CLR;
			ANAL_A_DOWN_SET;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_CLR;
			SW_UP_CTL_CLR;
			SW_AUTO_CTL_CLR;
			break;
		case DIGIT_DOWN:
			ANAL_DOWN_CLR;
			ANAL_UP_CLR;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_SET;
			SW_UP_CTL_CLR;
			SW_AUTO_CTL_CLR;
			break;
		case DIGIT_UP:
			ANAL_DOWN_CLR;
			ANAL_UP_CLR;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_CLR;
			SW_UP_CTL_SET;
			SW_AUTO_CTL_CLR;
			break;
		case DIGIT_A_DOWN:
			ANAL_DOWN_CLR;
			ANAL_UP_CLR;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_SET;
			SW_UP_CTL_CLR;
			SW_AUTO_CTL_SET;
			break;
		case DIGIT_A_UP:
			ANAL_DOWN_CLR;
			ANAL_UP_CLR;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_CLR;
			SW_UP_CTL_SET;
			SW_AUTO_CTL_SET;
			break;		
		case DIGIT_AUTO:
			ANAL_DOWN_CLR;
			ANAL_UP_CLR;
			ANAL_A_DOWN_CLR;
			ANAL_A_UP_CLR;

			SW_DOWN_CTL_CLR;
			SW_UP_CTL_CLR;
			SW_AUTO_CTL_SET;
			break;
	}
	gu8_JF_SW_Value = Value;
}
/*
void Enable_Power_Cylinder(u8 Value)
{
	if(gu8_Enable_Power_Cylinder_Value == Value)return;
	
	if(tbit(Value, 0))	ENABLE_CTL_SET;
	else 			ENABLE_CTL_CLR;

	if(tbit(Value, 1))	POWER_CTL1_SET;
	else 			POWER_CTL1_CLR;

	if(tbit(Value, 2))	POWER_CTL2_SET;
	else 			POWER_CTL2_CLR;

	if(tbit(Value, 6) )	SOL_CTL1_SET;
	else 			SOL_CTL1_CLR;

	if(tbit(Value, 7) )	SOL_CTL2_SET;
	else 			SOL_CTL2_CLR;

	gu8_Enable_Power_Cylinder_Value = Value;
}
*/

void Enable_Set(u8 Value)
{
	if(Value) ENABLE_CTL_SET;
	else 	ENABLE_CTL_CLR;
}
void Power_Set(u8 Value)
{
	switch(Value)
	{
		case 0:
			POWER_CTL1_OFF;
			POWER_CTL2_OFF;
			break;
		case 1:
			if(gu8_ModbusData[MD_ECU_TYPE] == ECU_P)
			{
				POWER_CTL1_ON;
				POWER_CTL2_OFF;
			}
			else
			{
				POWER_CTL1_OFF;
				POWER_CTL2_ON;
			}			
			break;
	}
		
}
void Cylinder_Set(u8 Cylinder_Select, u8 Value)
{
	if(Cylinder_Select==0)
	{	
		// Power 1
		if(Value)SOL_CTL1_SET;
		else       SOL_CTL1_CLR;
	}
	else
	{
		// Power 2
		if(Value)SOL_CTL2_SET;
		else       SOL_CTL2_CLR;
	}
}

void Lin_Slave_Type(void)
{
	u8 Value = 0;

	if(gu8_FL_Connected)Value = FL_TYPE;
	if(gu8_FR_Connected)Value = FR_TYPE;
	if(gu8_RL_Connected)Value = RL_TYPE;
	if(gu8_RR_Connected)Value = RR_TYPE;

	gu8_ModbusData[MD_LIN_SLAVE_TYPE] = Value;
}

